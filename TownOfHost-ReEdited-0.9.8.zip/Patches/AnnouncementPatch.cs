﻿using System;
using System.Collections.Generic;
using System.Linq;
using AmongUs.Data;
using AmongUs.Data.Player;
using Assets.InnerNet;
using HarmonyLib;
using Il2CppInterop.Runtime.InteropTypes.Arrays;

namespace TOHEBR;

// ##https://github.com/Yumenopai/TownOfHost_Y
public class ModNews
{
    public int Number;
    public int BeforeNumber;
    public string Title;
    public string SubTitle;
    public string ShortTitle;
    public string Text;
    public string Date;

    public Announcement ToAnnouncement()
    {
        var result = new Announcement
        {
            Number = Number,
            Title = Title,
            SubTitle = SubTitle,
            ShortTitle = ShortTitle,
            Text = Text,
            Language = (uint)DataManager.Settings.Language.CurrentLanguage,
            Date = Date,
            Id = "ModNews"
        };

        return result;
    }
}
[HarmonyPatch]
public class ModNewsHistory
{
    public static List<ModNews> AllModNews = new();

    // 
    public static void Init()
    {
        {
            // TOHE v2.4.3
            var news = new ModNews
            {
                Number = 100001, // 100001
                Title = "TownOfHostEditado Brasil v.0.9.8",
                SubTitle = "★Outro grande update? kakaka★",
                ShortTitle = "TOHE BR 0.9.8",
                Text = "<size=150%>Bem vindo ao TOHE BR v0.9.8.</size>\n\n<size=125%>Suporte para among us v2023.7.11.</size>\n"

                    + "\n【Base】\n - Baseado em TOH v4.1.2\r\n"
                    + "\n【Fixes】\n - Varios bugs resolvidos\n\r"
                    + "\n【Changes】\n - Adicionado /color /up e muitos os\n - No futuro irei fazer um grande mod\n\r"

                    + "\n【New Features】\n - Nova Função Twister (função pegada do discord)\n\r - Nova Função: Camaleão (veio do Project: Lotus)\n\r - Nova Função: Metamorfo\n\r - Nova Funçãp: Inspetor (função pelo PedrinnCAR no Discord)\n\r - Nova Função: Medusa\n\r - Novo add-on: Lazy\n\r - Novo add-on: Gravestone\n\r - Novo add-on: Autopsy (pelo TOHY)\n\r - Novo add-on: Loyal\n\r - Novo add-on: Parasight\n\r- Nova experimental função: Spiritcaller (role pelo blackzw no Discord)\n\r"

                    + "\n【Role Changes】\n - Varias coisas mudaram tipo o Opportunist\n\r",

                Date = "2023-7-14T00:00:00Z"

            };
            AllModNews.Add(news);
        }   

        {
            // When creating new news, you can not delete old news
            // TOHE v2.4.2
            var news = new ModNews
            {
                Number = 100000,
                Title = "TownOfHostEdited v2.4.2",
                SubTitle = "★★★★Ooooh bigger update★★★★",
                ShortTitle = "★TOHE v2.4.2",
                Text = "Added in some new stuff, along with some bug fixes.\r\nAmong Us v2023.3.28 is recommended so the roles work correctly.\n"

                    + "\n【Base】\n - Base on TOH v4.1.2\r\n"
                    + "\n【Fixes】\n - Fixed various black screen bugs (some still exist but should be less common)\r\n - Other various bug fixes (they're hard to keep track of)\r\n"
                    + "\n【Changes】\n - Judge now supports Guesser Mode\r\n - Background image reverted to use the AU v2023.3.28 size due to the recommended Among Us version being v2023.3.28\r\n - Many other unlisted changes\r\n - Mario renamed to Vector due to copyright concerns\r\n"

                    + "\n【New Features】\n - ###Impostors\n - Councillor\r\n - Deathpact (role by papercut on Discord)\r\n - Saboteur (25% chance to replace Inhibitor)\r\n - Consigliere (by Yumeno from TOHY)\r\n - Dazzler (role by papercut on Discord)\r\n - Devourer (role by papercut on Discord)\r\n"
                    + "\n ### Crewmates\n - Addict (role by papercut on Discord)\r\n - Tracefinder\r\n - Deputy\r\n - Merchant (role by papercut on Discord)\r\n - Oracle\r\n - Spiritualist (role by papercut on Discord)\r\n - Retributionist\r\n- Guardian\r\n - Monarch\r\n"
                    + "\n ### Neutrals\n - Maverick\r\n - Cursed Soul\r\n - Vulture (role by ryuk on Discord)\r\n - Jinx\r\n - Pickpocket\r\n - Ritualist\r\n - Traitor\r\n"
                    + "\n ### Add-ons\n - Double Shot (add-on by TommyXL)\r\n - Rascal\r\n"

                    + "\n【Role Changes】\n - Mimic now has a setting to see the roles of dead players, due to how useless this add-on was\r\n - A revealed Workaholic can no longer be guessed\r\n - Doctor has a new setting like Workaholic to be revealed to all (currently exposes evil Doctors, use at your own risk)\r\n - Mayor has a setting for a TOS mechanic to reveal themselves\r\n - Warlock balancing\r\n - Cleaner balancing (resets kill cooldown to value set in Cleaner settings)\r\n - Updated Monarch\r\n- Removed speed boost from Mare\r\n"
                    + "\n【Removals】\n - Removed Flash\r\n - Removed Speed Booster\r\n - Temporarily removed Oblivious",

                Date = "2023-7-5T00:00:00Z"

            };
            AllModNews.Add(news);
        }
    }

    [HarmonyPatch(typeof(PlayerAnnouncementData), nameof(PlayerAnnouncementData.SetAnnouncements)), HarmonyPrefix]
    public static bool SetModAnnouncements(PlayerAnnouncementData __instance, [HarmonyArgument(0)] ref Il2CppReferenceArray<Announcement> aRange)
    {
        if (AllModNews.Count < 1)
        {
            Init();
            AllModNews.Sort((a1, a2) => { return DateTime.Compare(DateTime.Parse(a2.Date), DateTime.Parse(a1.Date)); });
        }

        List<Announcement> FinalAllNews = new();
        AllModNews.Do(n => FinalAllNews.Add(n.ToAnnouncement()));
        foreach (var news in aRange)
        {
            if (!AllModNews.Any(x => x.Number == news.Number))
                FinalAllNews.Add(news);
        }
        FinalAllNews.Sort((a1, a2) => { return DateTime.Compare(DateTime.Parse(a2.Date), DateTime.Parse(a1.Date)); });

        aRange = new(FinalAllNews.Count);
        for (int i = 0; i < FinalAllNews.Count; i++)
            aRange[i] = FinalAllNews[i];

        return true;
    }
}
llNews[i];

        return true;
    }
}
